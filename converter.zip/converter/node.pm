package node;
use strict;

######################################################################
#
#  Class to store a logon tree node
#
#    Attributes:
#       value -> node content
#       parent -> reference to parent node
#       child -> position of word head of dependent subtree 
#       head ->  position of word head of head subtree 
#       order -> order we take into our parent's childlist
#       childlist-> array with references to children 
#
######################################################################


######################################################################
# Constructor

sub new {
    my $this = shift; 
    my $class = ref($this) || $this; 
  
    # create node and init attributes
    my $self={}; 
    $self ->{value} = undef;
    $self ->{parent} = undef;
    $self ->{head} = undef;
    $self ->{child} = undef;
    $self ->{order} = undef;
    $self ->{childlist} = [];
    bless $self, $class; 
    return ($self);
}
  
######################################################################
# Destructor

sub DESTROY {
    my $self=shift; 
    delete ($self->{value});  
    delete ($self->{parent});
    delete ($self->{head});
    delete ($self->{child});
    delete ($self->{order});
    delete ($self->{childlist});
}

######################################################################
# get/set node content

sub value {
    my $self = shift; 
    $self->{value} = shift if (@_);
    return $self->{value};
}

######################################################################
# get/set parent

sub parent{
    my $self=shift; 
    $self->{parent}=shift if (@_);
    return $self->{parent};
}

######################################################################
# get/set head

sub head{
    my $self=shift; 
    $self->{head}=shift if (@_);
    return $self->{head};
}

######################################################################
# get/set child

sub child{
    my $self=shift; 
    $self->{child}=shift if (@_);
    return $self->{child};
}
######################################################################
# get/set order

sub order{
    my $self=shift; 
    $self->{order}=shift if (@_);
    return $self->{order};
}

######################################################################
# get/set child list

sub childlist {
    my $self=shift; 
    if (@_) {push(@{$self->{childlist}},@_);}
    else { return @{$self->{childlist}}; }
}

######################################################################
# Dump tree

sub print {
    my ($self,$indent) = @_;

    my $prt = $indent."( $self->{value} ";
    if (@{$self->{childlist}} == 0) { 
        $prt .= ")"; 
    }
    else {
        foreach my $ch (@{$self->{childlist}}) {
           $prt .= "\n".$ch->print($indent."     ");
        }
        $prt .= ")"; 
    }

    return $prt;
}
  
1;
