
package tagset;
use strict;

######################################################################
#
#  Class to convert an EAGLES-like tag to a morphosyntactic description (MSD)
#
#  Attributes:
#   PAIR_SEP -> MSD pair separator (e.g. "=" in "gen=masc")
#   MSD_DEP -> MSD list separator (e.g. "|" in "gen=masc|num=pl")
#   feat -> map from PoS+index to feature name (e.g. "N:2"=>"gen", "N:3"=>"num")
#   val -> map from PoS+index+value to value value (e.g. "N:2:F"=>"fem", "N:3:P"=>"pl")
#   name -> map from PoS code to PoS name (e.g. "N"=>"noun", "V"=>"verb")
#   direct -> map PoS=>MSD for direct entry rules (e.g. "Fat"=>"pos=punct|type=exclamationmark|punctenclose=close")

######################################################################
# Constructor

sub new {
    my ($this,$file)=@_;
    my $class = ref($this) || $this; 
  
    # create tagset handler and init attributes
    my $self={}; 
    $self->{PAIR_SEP} = "=";    
    $self->{MSD_SEP} = "|" ;    
    $self->{feat} = {};
    $self->{val} = {};
    $self->{name} = {};    
    $self->{direct} = {};

    # read config file and load tagset structure into maps
    my $section=0;
    my $line=1;
    open(CONFIG,$file) or die "Error opening file '$file'\n";
    while (<CONFIG>) {
        chomp;
        if (/^\s*$/ or substr($_,0,1) eq "#") {next;} # skip comments and blank lines

        if (/<DecompositionRules>/) { $section=1; }
        elsif (/<\/DecompositionRules>/) { $section=0; }
        elsif (/<DirectTranslations>/) { $section=2; }
        elsif (/<\/DirectTranslations>/) { $section=0; }

        elsif ($section == 1) { # DecompositionRules
            my @line = split(/\s+/,$_);
            my $cat=$line[0]; # first field is category code (N,V, etc)
                              # second field is short tag size (not used here)
            my $pos=$line[2]; # third field is category name (noun, verb...)

            $self->{name}{$cat}=$pos; # store in map

            # follwing fields are morphological attributes and values
            for (my $i=3; $i<@line; $i++) {
                ## key for this attribute: cat+idx
                my $key = $cat."#".($i-2);
                ## separate feature name from values "postype/C:common;P:proper"
                my @k = split(/\//,$line[$i]);
                ## store name (e.g. "postype") for this position
                $self->{feat}{$key} = $k[0];
                ## store postition for this name (used for cross check only)
                $self->{feat}{$cat."#".$k[0]} = $i-2;

                my @v = split(/;/,$k[1]); ## separate values "C:common;P:proper"
                for (my $j=0; $j<@v; $j++) {
                    ## split value code:name "C:common"
                    my @t = split(/:/,$v[$j]);
                    ## store correspondence cat+indx+code=>name
                    $self->{val}{$key."#".uc($t[0])} = $t[1];
                }
            }
        }

        elsif ($section == 2) { # DirectTranslations
            my @line = split(/\s+/,$_);
            my $tag=$line[0];  # first field is full PoS tag
                               # second field is short tag (not used here)
            my $msd=$line[2];  # third field is MSD string
            $self->{direct}{$tag}=$msd;
        }

        else { die "Error in tagset file '$file', line $line\n"; }

        $line++;
    }
    close CONFIG;


    bless $self, $class; 
    return ($self); 
}


sub DESTROY {
    my $self=shift; 
    delete($self->{PAIR_SEP});
    delete($self->{MSD_SEP});
    delete($self->{feat});
    delete($self->{val});
    delete($self->{name});
    delete($self->{direct});
}

sub compute_msd_features() {
    my $self=shift; 
    my $tag=shift;

    # if a direct entry is found, use it
    if (defined $self->{direct}{$tag}) { return $self->{direct}{$tag}; }

    # otherwise, look for a decomposition rule
    my $cat=substr($tag,0,1);

    ## find category name
    my $n = $self->{name}{$cat};
    if (not defined $n) {
        print STDERR "TAGSET: Unknown category for tag $cat\n";
        return "";
    }
    my $msd = "pos".$self->{PAIR_SEP}.$n;

    ## find positional attributes and their values
    for (my $i=1; $i<length($tag); $i++) {
        my $key = $cat."#".$i;  ## field number (e.g N#2 -> 2nd field of a "N" tag)
        my $code = uc(substr($tag,$i,1)); ## feature code
        
        my $fname = $self->{feat}{$key};
        if (not defined $fname) {
            ## position description not found. There is no more information about this tag.
            return $msd;
        }

        if ($code !=~ /^[0\-\.]$/) {
            ## retrieve values for field+code (e.g. N#2#M -> "M" code found in 
            ## 2nd field of "N" tag is translated, e.g, as "masc")
            my $v =  $self->{val}{$key."#".$code};
            if (defined $v) {
                if ($v ne "0") { ## if value set to 0 -> ignore value
                    $msd .= $self->{MSD_SEP}.$fname.$self->{PAIR_SEP}.$v;
                }
            }
            elsif ($code ne "0") { 
                print STDERR "TAGSET: Tag $tag: Invalid code '$code' for feature '$fname'\n";
            }
        }
    }

    return $msd;
}

1;
