package word;
use strict;

######################################################################
#
#  Class to store a word in a CoNLL-like table
#
#    Attributes:
#      numToken -> position of the word in the sentence (count from 0)
#      word -> word form
#      lemma -> word lemma
#      cat -> word PoS 
#      dep -> dependency parent
#      dep -> dependency relation
#      pos -> PoS (as given by logon)
#      features -> MSD
#      funSem -> MSD
#      path -> path from word to the higest constituent headed by that word
#      count -> counter of already filled arguments

######################################################################
# Constructor

sub new {
    my $this=shift;
    my $class = ref($this) || $this; 
  
    # create node and init attributes
    my $self={}; 
    $self ->{numToken} = undef ;    
    $self ->{word} = "_" ;    
    $self ->{lemma} = "_" ;   
    $self ->{path} = "_" ;
    $self ->{cat} = "_" ;    
    $self ->{dep} = "_" ;
    $self->{deprel} = "_";
    $self ->{pos} = "_" ;   
    $self ->{features} = "_" ;
    $self->{funSem}= "_";
    $self->{count}= 0;
    bless $self, $class; 
    return ($self); 
}

######################################################################
# Destructor

sub DESTROY {
    my $self=shift; 
    delete ($self->{numToken});  
    delete ($self->{word});
    delete ($self->{lemma});
    delete ($self->{cap});
    delete ($self->{dep});
    delete ($self->{pos});
    delete ($self->{path});
    delete ($self->{deprel});
    delete ($self->{features});
    delete ($self->{funSem});
    delete ($self->{count});
}

######################################################################
# get/set features

sub features {
    my $self=shift; 
    $self->{features}=shift if (@_);
    return $self->{features};
}

######################################################################
# get/set funSem

sub funSem {
    my $self=shift; 
    $self->{funSem}=shift if (@_);
    return $self->{funSem};
}

######################################################################
# get/set dep

sub dep {
    my $self=shift; 
    $self->{dep}=shift if (@_);
    return $self->{dep};
}

######################################################################
# get/set cat

sub cat {
    my $self=shift; 
    $self->{cat}=shift if (@_);
    return $self->{cat};
}

######################################################################
# get/set pos

sub pos {
    my $self=shift; 
    $self->{pos}=shift if (@_);
    return $self->{pos};
}

######################################################################
# get/set deprel

sub deprel {
    my $self=shift; 
    $self->{deprel}=shift if (@_);
    return $self->{deprel};
}

######################################################################
# get/set lemma

sub lemma {
    my $self=shift; 
    $self->{lemma}=shift if (@_);
    return $self->{lemma};
}

######################################################################
# get/set path

sub path {
    my $self=shift; 
    $self->{path}=shift if (@_);
    return $self->{path};
}

######################################################################
# get/set count

sub count {
    my $self=shift; 
    $self->{count}=shift if (@_);
    return $self->{count};
}

######################################################################
# get/set form

sub word {
    my $self=shift; 
    $self->{word}=shift if (@_);
    return $self->{word};
}

######################################################################
# get/set id

sub numToken {
    my $self=shift; 
    $self->{numToken}=shift if (@_);
    return $self->{numToken};
}

1;
