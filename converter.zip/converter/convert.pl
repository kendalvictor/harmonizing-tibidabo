#! /usr/bin/perl

################################################################
##
##  convert.pl: Convert LOGON output to CoNLL dependency format
##
##  Author:  Lluís Padró
##  Copyright: (c) 2014 TALP Research Center
##             Universitat Politecnica de Catalunya
##             Barcelona, Spain
##
##    This program is free software; you can redistribute it and/or
##    modify it under the terms of the GNU Affero General Public
##    License as published by the Free Software Foundation; either
##    version 3 of the License, or (at your option) any later version.
##
##    This program is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
##    Affero General Public License for more details.
##
##    You should have received a copy of the GNU Affero General Public
##    License along with this program; if not, download it from
##    http://www.gnu.org/licenses/agpl-3.0.html, or write to the 
##    Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
##    Boston, MA 02111-1307 USA.
##
##    contact: Lluis Padro (padro@lsi.upc.es)
##             TALP Research Center
##             omega.S112 - Campus Nord UPC
##             08034 Barcelona.  SPAIN
##
################################################################

require "node.pm";
require "word.pm";
require "tagset.pm";

use strict;
use utf8;

# ----------------------------------------------
#
#         MAIN PROGRAM 
#
# ----------------------------------------------

## to store the OK analysis number for each sentence
my %analysisOK={};

## load list of exceptions for rule head identification
my @heads=();
open(HEAD,"./data/heads.dat") or die "Error opening file './data/heads.dat'\n";
while (<HEAD>) {
    chomp;
    if (/^\s*$/ or substr($_,0,1) eq "#") {next;} # skip comments and blank lines
    addHead($_);
}
close HEAD;

## load list of argument functions for a verb lexical entry
my %arguments={};
open(ARGS,"./data/arguments.dat") or die "Error opening file './data/arguments.dat'\n";
while (<ARGS>) {
    chomp;
    if (/^\s*$/ or substr($_,0,1) eq "#") {next;} # skip comments and blank lines

    # process function line
    my @line = split(/\s+/,$_);
    # get argument functions
    my $arg={};
    $arg->{RE_RULE}=$line[0];
    $arg->{RE_HPATH}=$line[1];
    $arg->{RE_CPATH}=$line[2];
    $arg->{COMPL}=$line[4];
    # store under appropriate key entry
    my $key=$line[3];
    push (@{$arguments{$key}},$arg);
}
close ARGS;

## load list of syntactic functions (for a given rule)
my @functions=();
open(FUNS,"./data/functions.dat") or die "Error opening file './data/functions.dat'\n";
while (<FUNS>) {
    chomp;
    if (/^\s*$/ or substr($_,0,1) eq "#") {next;} # skip comments and blank lines

    # process function line
    my @line = split(/\s+/,$_);
    # create struct and fill it up
    my $fun={};
    $fun->{RE_RULE} = $line[0];     # rule for node being checked
    $fun->{RE_HPATH} = $line[1];    # fill head path condition
    $fun->{RE_CPATH} = $line[2];    # fill child path condition
    $fun->{FUNCTION} = $line[3];    # fill function
    push(@functions,$fun);          # store entry
}
close FUNS;

## create tagset handler to convert PoS tags to MSD
my $tags = new tagset("./data/tagset.dat");

## check parameters, get directory with input logon analysis
if (@ARGV != 1) { die("Usage:  perl convert.pl inputDIR\n") };
my $inputDIR = $ARGV[0];

## open directory, dive in
opendir(IDH, "$inputDIR") or die("Cannot open directory '$inputDIR'");
close(IDH);

# process files in gicen subdirectory
loadAnalysisOK("$inputDIR/preference");
convertSentences("$inputDIR/result");

# ----------------------------------------------
#         SUBROUTINES
# ----------------------------------------------

################################################
# add exception head rule to list
sub addHead() {
    my $entry = shift;

    # process head rule line
    my @line = split(/\s+/,$entry);

    # create exception struct, and fill it up
    my $exc={};

    # rule pattern
    $exc->{RE_RULE} = $line[0];   

    # left child conditions
    my @r = split(/\//,$line[1]);
    # left child pattern
    $exc->{RE_CH0} = $r[0];
    # left child negative pattern
    $exc->{RE_NEG_CH0} = "-"; 
    if (@r>1) { $exc->{RE_NEG_CH0} = $r[1]; } 

    # right child conditions
    @r = split(/\//,$line[2]);
    # right child pattern
    $exc->{RE_CH1} = $r[0];
    # right child negative pattern
    $exc->{RE_NEG_CH1} = "-"; 
    if (@r>1) { $exc->{RE_NEG_CH1} = $r[1]; } 

    # right child conditions
    @r = split(/\//,$line[3]);
    # right child pattern
    $exc->{RE_SISTER} = $r[0];
    # right child negative pattern
    $exc->{RE_NEG_SISTER} = "-"; 
    if (@r>1) { $exc->{RE_NEG_SISTER} = $r[1]; } 

    # head child
    $exc->{HEAD} = $line[4];

    # semantic head child
    $exc->{HSEM} = $line[5];

    # whether to use HSEM as dependency head
    my $use_hs = lc(substr($line[6],0,1));
    if ($use_hs ne "y" and $use_hs ne "n") {
        print STDERR "Head rule '$entry' with invalid y/n value '$use_hs'. Assuming 'n'.\n";
        $use_hs = "n";
    }
    $exc->{USEHS} = ($use_hs eq "y");

    # store rule
    push(@heads,$exc);  
}

################################################
# load correct analysis index for each sentence
sub loadAnalysisOK {
    my($preference) = @_;

    open(PREF, "$preference") or die("Failed to open file '$preference'\n");    
    while (<PREF>) {
        chomp;
        my @fields = split /@/;
        $analysisOK{$fields[0]} = $fields[2];
    }
    close PREF;
}


################################################
# Read sentences in given file and convert to CoNLL format
sub convertSentences {
    my($result) = @_;

    open(RES, $result) or die("Failed to open file '$result'\n");    

    while (<RES>) {
        chomp;
        my @fields = split /@/;

        # if the line contains the right analysis for its sentence, process it
        if ($fields[1] eq $analysisOK{$fields[0]}) {
            # load the tree into a data structure
            my ($tree,@words) = readTree($fields[10]);

            # pretty print tree to STDERR, for convenience
            print STDERR "## Sentence $fields[0], analysis $fields[1]\n";
            print STDERR  $tree->print()."\n\n";

            # convert loaded tree to conll lines in @words
            tree2conll(\$tree,\@words);    

            # output words in CoNLL format
            foreach my $w (@words) {
                print $w->numToken()."\t".$w->word()."\t".$w->lemma()."\t".lc(substr($w->pos,0,1))."\t".$w->pos()."\t".$tags->compute_msd_features($w->pos())."\t".$w->dep()."\t".$w->funSem()."\t".$w->dep()."\t_   ".join(/#/,$w->path())."\n";
            }
            print "\n";
        }
    }
    close RES;
}    

################################################
# read a whole tree, just an initialization for 
# recursive function loadTree below.
sub readTree {
    my ($s) = @_;
    
    # take care of parenthesis tokens that do not
    # mark tree structure
    $s =~ s/"\("/"OPENPAR"/g;
    $s =~ s/\\\\"\(\\\\"/"OPENPAR"/g;
    $s =~ s/"\)"/"CLOSEPAR"/g;
    $s =~ s/\\\\"\)\\\\"/"CLOSEPAR"/g;
    $s =~ s/\(/\( /g;
    $s =~ s/\)/ \)/g;
    $s =~ s/"OPENPAR"/"\("/g;
    $s =~ s/"CLOSEPAR"/"\)"/g;

    # split tree tokens to ease parsing
    my @pars = split(/ /,$s);
    
    # parse parenthised sequence into the tree
    my $i=0;
    my $tk=1;
    my @words=();
    my $tree = loadTree(\$i,\$tk,\@pars,\@words);
    return ($tree,@words);
}

################################################
# Recursively load a subtree starting with "(" token at position $$i. 
# Index $$i is updated to first token after the read subtree.
# Tokens are renumbered according to their order (numbers in the tree do not match sometimes)
# @words is filled with one entry for each terminal node
sub loadTree {
    my ($i,$tk,$pars,$words) = @_;
    
    if (@$pars[$$i] ne "(") {
        die("Error reading tree. Unexpected node at '".@$pars[$i]."' ");  
    }
    
    # new tree starts, see which kind of node we find
    my $tree;
    $$i++;
    if (@$pars[$$i] =~ /^root/) {  # root node. Just skip it
        $$i++;
        $tree = loadTree($i,$tk,$pars,$words);
    }
    elsif (@$pars[$$i] =~ /^\".*\"$/) {  # Leaf node. Build node, load word, end recursion
        # Build node 
        $tree = new node();
        $tree->value(@$pars[$$i]." ".$$tk); 
        # Add entry to @words
        my $wd = new word();
        $wd->numToken($$tk);
        $wd->word(substr(@$pars[$$i],1,length(@$pars[$$i])-2));
        push(@$words,$wd);
        # update pointers and counters
        $$tk++;
        $$i+=3;
    }
    elsif (@$pars[$$i] =~ /^[0-9]+$/) {  # non-leaf node. Read information and recurse to children
        $$i++;
        $tree = new node();

        # get rule label, fixing some codification errors in the SRG rule names
        my $val = @$pars[$$i];   # rule label
        $val =~ s/v_np_ge/v-np_ge/g; 
        $val =~ s/dar_de_alta_v-np-pp_e_idm/dar-v-np-pp_e_idm/g;
        $val =~ s/dar_igual_v-modnp-ppa_idm/dar-v-adv-ppa_idm/g;
        $val =~ s/dar_igual_v-adv-pp_a_idm/dar-v-adv-ppa_idm/g;
        $val =~ s/igual-v-modnp-ppa_idm/dar-v-adv-ppa_idm/g;
        $val =~ s/dar_lugar_v-np-pp_e_idm/dar-v-np_npsv-pp_e_idm/g;
        $val =~ s/darse_cuenta_vprn-np-pp_e_idm/darse-vprn-np_npsv-pp_e_idm/g;
        $val =~ s/echar_de_menos_v-np-pp_e_idm/echar-v-np-pp_e_idm/g;
        $val =~ s/echar_en_falta_v-pp_a-pp_e_idm/echar-v-ppa-pp_e_idm/g;
        $val =~ s/encogerse_de_hombros_vprn-pp_e-idm/encogerse-vprn-pp_e_idm/g;
        $val =~ s/entrar_en_vigor_v-pp_e_idm/entrar-v-pp_e_idm/g;
        $val =~ s/formar_parte_de_idm/formar-v-np_npsv-pp_e_idm/g;
        $val =~ s/haber_lugar_v-np_npsn_idm/haber-v-np_npsv_idm/g;
        $val =~ s/hacerse_cargo_vprn-np-pp_e_idm/hacerse-vprn-np_npsv-pp_e_idm/g;
        $val =~ s/hacer_falta_idm/hacer_v-np/g;
        $val =~ s/hacer_uso_de_idm/hacer-v-np_npsv-pp_e_idm/g;
        $val =~ s/hacer_referencia_a_idm/hacer-v-np_npsv-pp_e_idm/g;
        $val =~ s/hacer_v-np-pp_a_idm/hacer-v-np_npsv-ppa_idm/g;
        $val =~ s/llevarse_bien_vprn-adv-pp_e-idm/llevarse-vprn-adv-pp_e_idm/g;
        $val =~ s/llevar_a_cabo_v-np-pp_e_idm/llevar-v-np-pp_e_idm/g;
        $val =~ s/poner_de_manifiesto_v-pp_e_idm/poner-v-pp_e_idm/g;
        #$val =~ s/poner_en_pr�ctica_v-pp_e_idm/poner-v-pp_e_idm/g;
        $val =~ s/poner_en_preligro_v-pp_e_idm/poner-v-pp_e_idm/g;
        $val =~ s/ponerse_en_contacto_vprn-pp_e-pp_e-idm/ponerse-vprn-pp_e-pp_e_idm/g;
        $val =~ s/poner_fin_v-np-pp_e_idm/poner-v-np_npsv-pp_e_idm/g;
	$val =~ s/pasar_np/pasar-v-np/g;
        $val =~ s/tener_en_cuenta_v-np-pp_e_idm/tener-v-np-pp_e_idm/g;
        $val =~ s/tener_lugar_v-np_npsn_idm/tener-v-np_npsv_idm/g;
        $val =~ s/tomar_cartas_v-np-pp_e_idm/tomar-v-np_npsv-pp_e_idm/g;
        $val =~ s/tomar_en_cuenta_v-np-pp_e_idm/tomar-v-np-pp_e_idm/g;
        $val =~ s/tomar_nota_v-np-pp_e_idm/tomar-v-np_npsv-pp_e_idm/g;
        $val =~ s/valer_la_pena_v-np_npsn_idm/valer-v-np_npsv_idm/g;
        $val =~ s/valer_la_pena_v-sbj-cp-p-sub_idm/valer-v-np_npsv_sbj_cp_p_sub_idm/g;
        $val =~ s/estar_adv-sbj_cp_p/estar_v-adv_sbj_cp_p/g;
        $val =~ s/estar_ap-sbj_cp_p/estar_v-ap_sbj_cp_p/g;
        $val =~ s/estar_ppart-sbj_vp_inf/estar_v-vp_ppart_sbj_vp_inf/g;
        $val =~ s/semi-colon_cm/semicolon_cm/g;
        $val =~ s/nu_/nu\-/g; 
        $val =~ s/\-idm/_idm/g; 
        $val =~ s/\-nsbj/_nsbj/g;
        $val =~ s/\-npsv/_npsv/g; 
        $val =~ s/\-optcm/_optcm/g; 
        $val =~ s/\-psv/_psv/g; 
        $val =~ s/\-rcp/_rcp/g; 
        $val =~ s/\-rfx/_rfx/g; 
        $val =~ s/\-seq/_seq/g; 
        $val =~ s/\-sbj/_sbj/g;
        $val =~ s/_npsn/_npsv/g; 
        $val =~ s/_rpc/_rcp/g; 
        $val =~ s/_sep/_seq/g; 
        $val =~ s/_v_/_v-/g; 
        $val =~ s/_-sbj/_sbj/g;
        $val =~ s/_np_ge/-np_ge/g; 
        $val =~ s/sbj-cp-p-sub/sbj_cp_p_sub/g;
        $val =~ s/sbj-cp-p/sbj_cp_p/g;
        $val =~ s/sbj-pl/sbj_pl/g;
        $val =~ s/cp_p-sub/cp_p_sub/g;
        $val =~ s/v-np-pp_ep_oeq_rfx/v-np-pp_e_oeq_rfx/g;
        $val =~ s/_v-np-pp_ep_oeq_rfx/_v-np-pp_e_oeq_rfx/g;
        $val =~ s/pp_e-vp-inf/pp_e_vp_inf/g;
        $val =~ s/vp-inf-oc/vp_inf_oc/g;
        $val =~ s/vp-inf/vp_inf/g;
        $val =~ s/pp-e/pp_e/g; 
        $val =~ s/np_pp/np-pp/g; 
        $val =~ s/_v-np\*/_v-np/g;
        $val =~ s/_v-np-pp\*/_v-np-pp/g;
        $val =~ s/_v-np-pp_e\*/_v-np-pp_e/g;
        $val =~ s/v-pp-inf-seq/v-pp_e_vp_seq/g; 
        $val =~ s/pp_aj/pp_e_ap/g;
        $val =~ s/pp_e_vp_nsbj/pp_e_vp_inf_nsbj/g; 
        $val =~ s/pp_seq_como/pp_e_seq/g;
        $val =~ s/pp_seq_de/pp_e_seq/g;
        $val =~ s/pp_seq/pp_e_seq/g;
        $val =~ s/vprn-pp_nsbj/vprn-pp_e_nsbj/g;
        $val =~ s/_v-q/_v-cp_q/g; 
        $val =~ s/pp_e_cp_p_a/pp_e_cp_p/g; 
        $val =~ s/pp_e_cp_p_con/pp_e_cp_p/g; 
        $val =~ s/pp_e_cp_p_de/pp_e_cp_p/g; 
        $val =~ s/pp_e_cp_p_en/pp_e_cp_p/g; 
        $val =~ s/pp_e_cp_p_por/pp_e_cp_p/g; 
        $val =~ s/pp_e_cp_p_sub_a/pp_e_cp_p_sub/g; 
        $val =~ s/pp_e_cp_p_sub_de/pp_e_cp_p_sub/g; 
        $val =~ s/pp_e_a/pp_e/g; 
        $val =~ s/pp_e_contra/pp_e/g; 
        $val =~ s/pp_e_con/pp_e/g; 
        $val =~ s/pp_e-con/pp_e/g; 
        $val =~ s/pp_e_de/pp_e/g; 
        $val =~ s/pp_e_entre/pp_e/g; 
        $val =~ s/pp_e_en/pp_e/g; 
        $val =~ s/pp_e_hacia/pp_e/g; 
        $val =~ s/pp_e_para/pp_e/g; 
        $val =~ s/pp_e_por/pp_e/g; 
        $val =~ s/pp_e_sobre/pp_e/g; 
        $val =~ s/pp_e_son/pp_e/g; 
        $val =~ s/pp_e_rfx_a/pp_e_rfx/g; 
        $val =~ s/pp_e_rfx_en/pp_e_rfx/g; 
        $val =~ s/pp_e_vp_a/pp_e_vp/g; 
        $val =~ s/pp_e_vp_de/pp_e_vp/g; 
        $val =~ s/pp_e_vp_en/pp_e_vp/g; 
        $val =~ s/pp_e_vp_inf_ssr_de/pp_e_vp_inf_ssr/g; 
        $val =~ s/pp_e_vp_inf_ssr_por/pp_e_vp_inf_ssr/g; 
        $val =~ s/np-pp_sor_rfx_de/np-pp_e_sor_rfx/g;
        $val =~ s/np-pp_de_sor_rfx/np-pp_e_sor_rfx/g;
        $val =~ s/prd_np-pp_sor/np-pp_e_sor/g;
        $val =~ s/np-pp_sor/np-pp_e_sor/g;
        $val =~ s/np-pp_sor_rfx/np-pp_e_sor_rfx/g;
        $val =~ s/np-pp_ae/np-pp_e/g; 
        $val =~ s/_v-v-pp_a/_v-ppa/g; 
        $val =~ s/_v-ppa_a/_v-ppa/g; 
        $val =~ s/_vpron/_vprn/g; 
        $val =~ s/pp_p_cp_p/pp_e_cp_p/g;
        $val =~ s/v-pp-pp_a_sbj_cp/v-np-ppa_sbj_cp_p/g;
        $val =~ s/_a-np-pp_e/_v-np-pp_e/g; 
        $val =~ s/para_v-vp-vm/para_p-vp-vm/g;  
        $val =~ s/pp_a/ppa/g; 
        $tree->value($val);

        $$i += 4;        
        my $nc=1;
        while (@$pars[$$i] eq "(") {
            my $ch = loadTree($i,$tk,$pars,$words);
            $ch->parent($tree);
            $ch->order($nc);
            $tree->childlist($ch);
            $nc++;
        }         

    }
    else {
        die("Unknown node type ($$i) [@$pars[$$i]]\n");
    }
    
    if (@$pars[$$i] ne ")") {
        die("Error reading tree. Expecting ')', found @$pars[$$i]."); 
    }
    $$i++;
    
    return $tree;
}

################################################
# Complete CoNLL word table.
# Just an initial call to recursive function convertTree below

sub tree2conll {
    my ($tree,$words) = @_;
    
    # call recursive function to compute and set heads in @words
    my ($hd,$hs,$dp);
    print STDERR "BUILDING DEPENDENCY TREE\n";
    ($hd,$hs,$dp) = convertTree($tree,$words,1);
    # tree root should have dependency 0 and function ROOT.
    @$words[$hd-1]->dep(0);
    # @$words[$hd-1]->funSem("ROOT");
    @$words[$hd-1]->funSem("top");

    # call recursive function to assign syntactic functions
    print STDERR "SETTING SYNTACTIC FUNCTIONS\n";
    setFunctions($tree,$words);
}

################################################
# Complete CoNLL word table with:
#    - dependency (head/rel) information from tree structure
#    - PoS & lemma (from intermediate nodes)
#
# parameters:
#  $tree: subtree to convert
#  $words: word array where results are stored
#  $pos: whether $tree was left (1) or right (2) child in the level above
#
# results:
#   head:  position in @$words of the word heading the subtree
#   depth: depth of the subtree branch to the head.

sub convertTree {
    my ($tree,$words) = @_;

    my @children = $$tree->childlist();
    my $numch = @children;

    if ($numch == 0) {  
        # leaf node, complete word with needed info
        my $numtk = processLeafNode($tree,$words);
        return ($numtk,$numtk,0);
    }

    elsif ($numch == 1) {  # unary rule, skip it.
        my ($h,$hs,$d);
        ($h,$hs,$d) = convertTree(\$children[0],$words);
        return ($h,$hs,$d+1);
    }

    elsif ($numch == 2) {  # binary rule, dive to children

        # process children, find out the head of each subtree
        my ($h0,$hs0,$d0,$h1,$hs1,$d1);
        ($h0,$hs0,$d0) = convertTree(\$children[0],$words);
        ($h1,$hs1,$d1) = convertTree(\$children[1],$words);

        # fix subtree dependencies according to rule head

        # check for exception entries for this rule
        # $hpos =  0: no entries, 1: left head, 2: right head
        # $add = boolean, whether child path is to be added to head path
        my ($hpos,$hspos,$use_hsem) = checkHeads($tree);

        # if no head was found by exception rules, use rule name to deduce behaviour
        if ($hpos==0 and $$tree->value() =~ /^hd\-/) { $hpos=1; $hspos=1; }
        elsif ($hpos==0 and $$tree->value() =~ /\-hd/) { $hpos=2; $hspos=2; }

        my $child;
        my $head;
        my $depth_h;
        my $depth_c;
        if ($hpos==1) {  # left child is the head, set dependency and function
            $head = $h0;
            $child = $h1;
            $depth_h = $d0+1;
            $depth_c = $d1+1;
        }
        elsif ($hpos==2) {  # right child is the head, set dependency and function
            $head = $h1;
            $child = $h0;
            $depth_h = $d1+1;
            $depth_c = $d0+1;
        }
        else {   # head was not identified, something is wrong
            die("Binary rule ".$$tree->value()." with no explicit head and no exception defined."); 
        }

        # child's path ends here. Cut it
        my @cpl = split(/:/,@$words[$child-1]->path());
        splice @cpl,$depth_c-1;
        @$words[$child-1]->path(join(':',@cpl));

        my $hsem=$head;
        my $chsem=$child;
        if ($hspos==1) { 
            $hsem = $hs0; 
            $chsem = $hs1;
        } 
        elsif ($hspos==2) { 
            $hsem = $hs1; 
            $chsem = $hs0;
        } 

        # set dependency
        if ($use_hsem) {
            @$words[$chsem-1]->dep($hsem);
            $$tree->head($hsem);
            $$tree->child($chsem);
        }
        else { 
            @$words[$child-1]->dep($head); 
            $$tree->head($head);
            $$tree->child($child);
        }

        return ($head,$hsem,$depth_h);
    }

    elsif ($numch == 4) {  # Special elision rule. Use ad-hoc structure. This should be improved some day
        # Process children, find out the head of each subtree
        my ($h0,$h1,$h2,$h3,$d0,$dkk);
        ($h0,$d0) = convertTree(\$children[0],$words);
        ($h1,$dkk) = convertTree(\$children[1],$words);
        ($h2,$dkk) = convertTree(\$children[2],$words);
        ($h3,$dkk) = convertTree(\$children[3],$words);

        print STDERR "Applying gap rule\n";

        # Child 0 is the head, child 1 is directly under it, it is the coordination
        @$words[$h1-1]->dep($h0);
        @$words[$h1-1]->funSem("coor");

        # Child 2 is under child 1
        @$words[$h2-1]->dep($h1);
        # and it is either SUBJ-GAP or COMP-GAP
       # if ($$tree->value() eq "cl_nv-sbc_c") { @$words[$h2-1]->funSem("SUBJ-GAP"); }
        if ($$tree->value() eq "cl_nv-sbc_c") { @$words[$h2-1]->funSem("gap"); }
       # else { @$words[$h2-1]->funSem("COMP-GAP"); }
        else { @$words[$h2-1]->funSem("gap"); }

        # Child 2 is also under child 1
        @$words[$h3-1]->dep($h1);
        # and it is either COMP-GAP or MOD-GAP
        if ($$tree->value() eq "cl_nv-sbc_c" or $$tree->value() eq "vp_cr-cc_c") { 
           # @$words[$h3-1]->funSem("COMP-GAP"); 
            @$words[$h3-1]->funSem("gap"); 
        }
        # else { @$words[$h3-1]->funSem("MOD-GAP"); }
        else { @$words[$h3-1]->funSem("gap"); }

        return ($h0,$h0,$d0);
    }
    else {
        die ("Unexpected rule '".$$tree->value()."' with $numch children nodes!!");
    }
}


################################################
# Complete CoNLL word table with:
#    - syntactic function information

sub setFunctions {
    my ($tree,$words) = @_;

    my @children = $$tree->childlist();
    my $numch = @children;

    if ($numch == 0) {  
        # leaf node, nothing to do;
        return;
    }

    elsif ($numch == 1) {  # unary rule, skip it.
        setFunctions(\$children[0],$words);
        return;
    }

    elsif ($numch == 2) {  # binary rule, dive to children

        # process children, set functions in each subtree
        setFunctions(\$children[0],$words);
        setFunctions(\$children[1],$words);

        # Find out function of the child, taking into account current rule, 
        # subcat information, and already filled slots
        my $head = $$tree->head();
        my $child = $$tree->child();
        my $fun = getFunction($$tree->value(),\@$words,$head-1,$child-1);
        @$words[$child-1]->funSem($fun);

        return;
    }

    elsif ($numch == 4) { 
        # Special elision rule. Use ad-hoc structure. 
        # Both structure and functions are fixed in 'convertTree'

        # process children, set functions for subtrees
        setFunctions(\$children[0],$words);
        setFunctions(\$children[1],$words);
        setFunctions(\$children[2],$words);
        setFunctions(\$children[3],$words);

        return;
    }
    else {
        die ("Unexpected rule '".$$tree->value()."' with $numch children nodes!!");
    }
}


################################################
# Process leaf node and extract word information 
# for ConLL table

sub processLeafNode {
    my ($tree,$words) = @_;

    # ------ DEPHEAD
    # by now, dependency head is the same word. 
    # Parent will fix it if needed
    my @val = split(/ /,$$tree->value());
    my $numtk = $val[1];
    # store dep in conll table
    @$words[$numtk-1]->dep($numtk);
    
    # ------ LEMMA
    # get form and length in tokens (for multiwords)
    my @form = split(/_/,$val[0]);
    my $ntf = @form;
    if ($val[0] =~ /([aA]|[Dd]e)_el/) { $ntf--; }
    # get to parent, which contains the lemma
    my @lemcomp=();
    my $v = $$tree->parent()->value();
    if ($v=~/^(nu-|pname|date)/) {
        push @lemcomp,$v;
        $ntf=1;
    }
    else {
        @lemcomp = split (/-/,$v);
    }

    my $lem = shift @lemcomp;
    my @lem = split (/_/,$lem);
    # build the lemma using as many tokens as (multi)word length
    $lem = join('_',@lem[0 .. $ntf-1]);
    if ($lem =~ /^(nu-|pname|date)/)  {
         # special no-lemma cases
        $ntf = 0; 
    }
    # add the rest to lemcomp
    unshift @lemcomp,@lem[$ntf .. @lem-1];

    # store lemma
    @$words[$numtk-1]->lemma($lem); 

    # store rest of lemma information about complements or modifiers
    my $cmp = join('-',@lemcomp); 

    # ------ POS
    # get to grandparent, which contains the PoS tag
    my $posnode = $$tree->parent()->parent();
    # except in some cases (e.g. clitics) when it is higher
    while ($posnode->value() =~ /[_\-]/ or $posnode->value() =~ /^(pname|date)/) { 
        # add intermediate nodes to complement/modifiers info.
        $cmp .= ":".$posnode->value();
        $posnode = $posnode->parent(); 
    }

    ## add to $cmp all nodes up to root, in case some rules want to refer to it
    my $posnodeaux=$posnode;
    while (defined $posnodeaux) {
        $cmp .= ":".$posnodeaux->value();
        $posnodeaux = $posnodeaux->parent(); 
    }

    # store complement/modifiers info
    @$words[$numtk-1]->path($cmp); 

    my $pos = $posnode->value();
    # if there are clitics still above, add them to PoS
    $posnode = $posnode->parent();
    while ($posnode->value() =~ /^\+/) { 
        $pos .= $posnode->value(); 
        $posnode = $posnode->parent();
    }
    # uppercase PoS appropriately, and store in conll table
    $pos = ( substr($pos,0,1) eq "f" ? "F".substr($pos,1) : uc($pos) );
    @$words[$numtk-1]->pos($pos); 

    return $numtk;
}

################################################
# Check if given rule matches any on exception list,
# and return head if found

sub checkHeads {
    my ($tree) = shift;

    my $rule = $$tree->value();
    my @children = $$tree->childlist();
    my $numch = @children;

    my $sister = undef;
    my $parent = $$tree->parent();
    if (defined($parent)) {
        my @siblings = $parent->childlist();
        my $mypos = $$tree->order();
        if (@siblings>1 and ($mypos==1 or $mypos==2)) {
            # get our sister (if we are child 1, 3-1 => 2; if we are child 2, 3-2=>1)
            # (minus one because of 0-idexed array)
            $sister = @siblings[2-$mypos];
        }
    }
    
    print STDERR "checking subtree ".$$tree->value().". (Sister=".(defined($sister) ? $sister->value() : "undef").")...";

    for (my $e=0; $e < @heads; $e++) { 
       # if the rule name matches the main condition, look further
       if ($rule =~ /$heads[$e]->{RE_RULE}/) {  
           # if there are conditions on children (and maybe sister), check them
           if ( (($heads[$e]->{RE_CH0} eq "-" and $heads[$e]->{RE_NEG_CH0} eq "-") or 
                 ($numch>0 and checkSubtree(\$children[0],$heads[$e]->{RE_CH0},$heads[$e]->{RE_NEG_CH0}))) and

                (($heads[$e]->{RE_CH1} eq "-" and $heads[$e]->{RE_NEG_CH1} eq "-") or 
                 ($numch>1 and checkSubtree(\$children[1],$heads[$e]->{RE_CH1},$heads[$e]->{RE_NEG_CH1}))) and

                (($heads[$e]->{RE_SISTER} eq "-" and $heads[$e]->{RE_NEG_SISTER} eq "-") or 
                 (defined($sister) and checkSubtree(\$sister,$heads[$e]->{RE_SISTER},$heads[$e]->{RE_NEG_SISTER}))) ) 
           {
               print STDERR "Applying exception rule: $heads[$e]->{RE_RULE}  $heads[$e]->{RE_CH0}/$heads[$e]->{RE_NEG_CH0}  $heads[$e]->{RE_CH1}/$heads[$e]->{RE_NEG_CH1}  $heads[$e]->{RE_SISTER}/$heads[$e]->{RE_NEG_SISTER}  $heads[$e]->{HEAD}  $heads[$e]->{HSEM}  $heads[$e]->{USEHS} \n";
               return ($heads[$e]->{HEAD},$heads[$e]->{HSEM},$heads[$e]->{USEHS});
           }
       }
    }
    print STDERR "No matching exception rule, use default head\n";
    return (0,0);
}

################################################
# Check if given subtree contains any node matching
# $rex with no node matching $neg in the path.

sub checkSubtree {
    my ($tree,$rex,$neg) = @_;

    #print STDERR "    checking subtree ".$$tree->value()." for node matching $rex, with barrier $neg.\n";

    my @children = $$tree->childlist();
    my $numch=@children;

    # we are a leaf, no checks needed. There is no such node
    if ($numch == 0) { return 0; }

    # not a leaf, check current node.

    # if we found the barrier, give up on this subtree
    if ($neg ne "-" and $$tree->value() =~ /$neg/) { 
        print STDERR "  barrier ($neg) found: ".$$tree->value().", abandon path.\n";
        return 0; 
    }

    # if we found the desired node, we're done
    if ($rex ne "-" and $$tree->value() =~ /$rex/) {
        print STDERR "  target ($rex) found: ".$$tree->value()."\n";
        return 1; 
    }
    
    ## current node didn't solve the problem one way or another, keep looking in children
    for ( my $j=0; $j<$numch; $j++ ) {
        if (checkSubtree(\$children[$j],$rex,$neg)) { return 1; }
    }
    
    ## We reached the end without finding what we were looking for.
    return 0;
}


################################################
# Finc out which function has the dependant in 
# the given rule.
sub getFunction {
    my ($rule,$words,$hpos, $cpos) = @_;
    
    my $lemma = @$words[$hpos]->lemma();
    my $clemma = @$words[$cpos]->lemma();
    my $hpath = @$words[$hpos]->path();
    my $cpath = @$words[$cpos]->path();

    my @cmps = split(/:/,$hpath);

    print STDERR "Computing syntactic function at node ($rule, $lemma [$hpath], $clemma [$cpath]) \n"; 

    for my $c (@cmps) {
        print STDERR "    Retrieving rules for $c ($lemma) \n"; 

        my $key = undef;
        if (defined $arguments{$lemma."_".$c}) { $key = $lemma."_".$c; }
        elsif (defined $arguments{"_".$c}) { $key = "_".$c; }

        if (defined $key) {
            print STDERR "    Found ".@{$arguments{$key}}." possible rules for $key in arguments.dat \n"; 
            for (my $r=0; $r<@{$arguments{$key}}; $r++) {
                print STDERR "    Check conditions for rule $r: $arguments{$key}[$r]->{RE_RULE}  $arguments{$key}[$r]->{RE_HPATH}  $arguments{$key}[$r]->{RE_CPATH}  $key  $arguments{$key}[$r]->{COMPL}\n"; 

                print STDERR "      Checking $rule =~ /$arguments{$key}[$r]->{RE_RULE}/ \n";
                print STDERR "           and $hpath =~ /$arguments{$key}[$r]->{RE_HPATH}/ \n";
                print STDERR "           and $cpath =~ /$arguments{$key}[$r]->{RE_CPATH}/ \n"; 
            
                if ($rule =~ /$arguments{$key}[$r]->{RE_RULE}/ and $hpath =~ /$arguments{$key}[$r]->{RE_HPATH}/ and $cpath =~ /$arguments{$key}[$r]->{RE_CPATH}/ ) {
                    print STDERR "      Conditions match, applying rule.\n";

                    my @args = split(/,/,$arguments{$key}[$r]->{COMPL});                    

                    # Rule matched, get appropriate function dependening on argument position
                    my $a;
                    if ($rule eq "hd-cmp_scd_c") { 
                        # inversion rule, get second function first
                        $a = 1; 
                    }
                    elsif (@args>1 and ($rule eq "hd-cmp_c" or $rule eq "ct-hd_c")) { 
                        # multiargument rule, get appropriate function depending on current argument count
                        my $i = @$words[$hpos]->count();
                        @$words[$hpos]->count($i+1);
                        $a = $i;
                    }
                    else {
                        # otherwise, get first function
                        $a = 0;
                    }
                    print STDERR "      Under ".@args."-argument rule $rule. result is arg $a: $args[$a]\n";
                    return $args[$a];

                }
                else { print STDERR "      Conditions do not match.\n"; }
            }
        }
    }

    
    print STDERR "    No matching rule found in arguments.dat. Check functions.dat\n"; 

    for my $c (@cmps) {   
        for (my $f=0; $f < @functions; $f++) { 
            # if the rule name matches the main condition, we're done
            if ($rule =~ /$functions[$f]->{RE_RULE}/ and $hpath =~ /$functions[$f]->{RE_HPATH}/ and $cpath =~ /$functions[$f]->{RE_CPATH}/) {  
                print STDERR "    Found match in 'functions' rule: $functions[$f]->{RE_RULE}  $functions[$f]->{RE_HPATH}  $functions[$f]->{RE_CPATH}  $functions[$f]->{FUNCTION} \n"; 
                return $functions[$f]->{FUNCTION};
            }
        }       
    }
    
    print STDERR "    No matching function for $rule, $lemma, $hpath\n"; 
    return "UNDEF";    
}

